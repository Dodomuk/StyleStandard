package order;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class IndexController
 */
@WebServlet("/order/*")
public class OrderController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	OrderService orderService = new OrderService();
	Order order = new Order();
	/**
	 * Default constructor.
	 */
	public OrderController() {
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String[] uriArr = request.getRequestURI().split("/");
		switch (uriArr[uriArr.length - 1]) {
		case "order":
			orderlist(request, response); //지수씨 드릴때 수정
			break;
		case "order_payment":
			order_payment(request, response);
			break;
		case "orderlist":
			orderlist(request, response);
			break;
		}
//		request.getRequestDispatcher("/WEB-INF/view/order/order_payment.jsp")
//		.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private void order(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.getRequestDispatcher("/WEB-INF/view/order/order.jsp").forward(request, response);

	}

	private void order_payment(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.getRequestDispatcher("/WEB-INF/view/order/order_payment.jsp").forward(request, response);

	}

	private void orderlist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		
		int order_code = (int)(Math.random()*89999999+10000000);
		
		while(orderService.checkOverlappingID(order_code) == 0) {

			order_code = (int)(Math.random()*89999999+10000000);
		
		}
		
		
		String user_id = (String)session.getAttribute("id");
		String ship_address = "서초동";
		// int product_code = Integer.parseInt(request.getParameter("product_code"));
		
		 //현재시간 가져오기
System.out.println(order_code);
System.out.println(user_id);
System.out.println(ship_address);
		order.setOrder_code(order_code);
		order.setUser_id(user_id);
		order.setShip_address(ship_address);
		/*
		 * order.setRent_date(sqlDate); order.setRent_return_date(sqlDate + );
		 */
		// order.setProduct_code(product_code);

        orderService.insertOrder(order);
		request.getRequestDispatcher("/WEB-INF/view/order/orderlist.jsp").forward(request, response);

	}

}
