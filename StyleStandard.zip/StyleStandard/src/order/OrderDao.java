package order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.error.DataAccessException;
import common.error.ErrorCode;
import common.jdbc.JDBCTemplate;

public class OrderDao {

	JDBCTemplate jdt =  JDBCTemplate.getInstance();
	//게시판 테이블에 게시글 저장
	
	public int checkOverlappingID(Connection conn, int orderID) { //같은 코드가 있는지 확인
		PreparedStatement pstm = null;
		boolean rset = false;
		int res = 0;
		try {

			String query = "select order_code from st_order where order_code=?";

			pstm = conn.prepareStatement(query);
			pstm.setInt(1, orderID);
			rset = pstm.execute();

			if(rset == true) {
				res++;
			}}catch (SQLException e) {
				throw new DataAccessException(ErrorCode.CST02, e);
			}finally {
				jdt.close(pstm);
			}
			
			return res;
	}
	
	public int insertOrder(Connection conn, Order order) {
		int res = 0;
		PreparedStatement pstm = null;
		
		try {
			String sql = "insert into st_order "
					+ "(order_code,user_id,ship_address,product_code) "
					+ "values(?,?,?,?)";
			pstm = conn.prepareStatement(sql);
			
			pstm.setInt(1, order.getOrder_code());
			pstm.setString(2, order.getUser_id());
			pstm.setString(3, order.getShip_address());
			pstm.setInt(4, order.getProduct_code());
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.CST02, e);
		}finally {
			jdt.close(pstm);
		}
		System.out.println("시스템 정상 DAO");
		return res;
	}
	

	
}
