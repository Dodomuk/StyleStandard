package product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import common.error.DataAccessException;
import common.error.ErrorCode;
import common.jdbc.JDBCTemplate;

public class ProductDao {

	JDBCTemplate jdt =  JDBCTemplate.getInstance();

	StyleBanner sb = new StyleBanner();
	//게시판 테이블에 게시글 저장
	
	public int checkOverlappingPRODUCT(Connection conn, int product_code) { //같은 코드가 있는지 확인
		PreparedStatement pstm = null;
		boolean rset = false;
		int res = 0;
		try {
			String query = "select product_code from product where product_code=?";

			pstm = conn.prepareStatement(query);
			pstm.setInt(1, product_code);
			rset = pstm.execute();

			if(rset == true) {
				res++;
			}}catch (SQLException e) {
				throw new DataAccessException(ErrorCode.PD01, e);
			}finally {
				jdt.close(pstm);
			}
			
			return res;
	}
	
	public int insertProduct(Connection conn, Product product) {
		
		int res = 0;
		PreparedStatement pstm = null;
		
		try {
			String sql = "insert into product "
					+ "(product_code,product_quantity,product_price,product_size,product_name,product_img,product_info,product_category)"
					+ "values(?,?,?,?,?,?,?,?)";
			
			pstm = conn.prepareStatement(sql);
			
			pstm.setInt(1, product.getProduct_code());
			pstm.setInt(2, product.getProduct_quantity());
			pstm.setInt(3, product.getProduct_price());
			pstm.setString(4, product.getProduct_size());
			pstm.setString(5, product.getProduct_name());
			pstm.setString(6, product.getProduct_img());
			pstm.setString(7, product.getProduct_info());
			pstm.setInt(8, product.getProduct_category());
			
			res = pstm.executeUpdate();
			
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.PD02, e);
		}finally {
			jdt.close(pstm);
		}
		System.out.println("시스템 정상 DAO");
		return res;
	}
	
	
	/*
	 * public int styleNumCount(Connection conn) { int res=0; PreparedStatement pstm
	 * = null; ResultSet rset = null; try { String sql =
	 * "select product_code from product"; pstm = conn.prepareStatement(sql);
	 * 
	 * rset = pstm.executeQuery(); ResultSetMetaData rsmd = rset.getMetaData(); res
	 * = rsmd.getColumnCount();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } finally {
	 * jdt.close(rset,pstm); }
	 * 
	 * System.out.println(res); return res; }
	 */
	 
}
