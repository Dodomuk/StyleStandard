package product;

public class StyleBanner {

	private String styleNum;

	public String getStyleNum() {
		return styleNum;
	}

	public void setStyleNum(String styleNum) {
		this.styleNum = styleNum;
	}
	
	
	
	
}
