package com.kh.toy.member.model.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.kh.toy.common.code.ErrorCode;
import com.kh.toy.common.exception.DataAccessException;
import com.kh.toy.common.jdbc.JDBCTemplate;
import com.kh.toy.member.model.vo.Member;

public class MemberDao {
	
	//DAO : DBMS에 접근해 데이터를 조회, 수정, 삽입, 삭제 요청을 보내는 클래스
	//DAO의 메서드는 하나의 쿼리만 처리하도록 작성한다.
	JDBCTemplate jdt = JDBCTemplate.getInstance();
	
	//로그인
	//매개변수로 ID와 PASSWORD를 전달받아, ID와 PASSWORD로 식별할 수 있는
	//회원정보를 반환하는 메서드
	public Member memberAuthenticate(Connection conn, String userId, String password) {
		Member member = null;
		PreparedStatement pstm = null;
		ResultSet rset = null;
		
		try {		
			String query = "select * from tb_member where user_id = ?"
					+ "and password = ? and is_leave = 0";
			
			//3. sql구문을 DBMS에 요청할 객체 생성
			pstm = conn.prepareStatement(query);
			
			//4. preparedStatement의 쿼리를 완성
			//setString(1,userId) : 첫번째 ?에 userId값을 넣어라.
			pstm.setString(1, userId);
			pstm.setString(2, password);
			
			//5. 쿼리문을 실행하고 질의결과(ResultSet)을 받음
			rset = pstm.executeQuery();
			
			//6. resultSet 인스턴스에 담겨있는 정보를 VO객체로 옮겨담기
			//resultSet.next() 
			//next() : 현재 row에서 다음 row의 데이터를 읽어오고 true를 반환.
			//만약 다음 row가 존재하지 않으면 false 반환
			if(rset.next()) {
				member = new Member();
				member.setUserId(rset.getString("user_id"));
				member.setPassword(rset.getString("password"));
				
				//현재 테이블에서 회원 등급 코드가 넘어오고 있는데
				//코드를 등급명으로 변경하여 member 인스턴스에 넣어주세요.
				member.setGrade(rset.getString("grade"));
				member.setTell(rset.getString("tell"));
				member.setRegDate(rset.getDate("reg_date"));
				member.setEmail(rset.getString("email"));
				member.setRentableDate(rset.getDate("rentable_date"));
				member.setIsLeave(rset.getInt("is_leave"));
			}
		//SQLException: checked Exception 
		//Checked Exception을 받아서 UnChecked Exception으로 변환해서 반환
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.SM01,e);
		} finally {
			jdt.close(rset, pstm);
		}
		 
		return member;
	}
	
	public Member selectMemberById(Connection conn, String userId){
		Member member = null;
		PreparedStatement pstm = null;
		ResultSet rset = null;
		try{
			String query = "select * from tb_member where user_id = ?";
			
			//3. 쿼리문 실행용 객체를 생성
			pstm = conn.prepareStatement(query);
			//4. PreparedStatement의 쿼리문을 완성
			pstm.setString(1, userId);
			//5. 쿼리문 실행하고 결과(resultSet)를 받음
			rset = pstm.executeQuery();
			
			if(rset.next()) {
				member = new Member();
				member.setUserId(rset.getString("user_id"));
				member.setGrade(rset.getString("grade"));
				member.setEmail(rset.getString("email"));
				member.setTell(rset.getString("tell"));
				member.setRegDate(rset.getDate("reg_date"));
			}
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.SM01,e);
		}finally {
			jdt.close(rset,pstm);
		}
		
		return member;
	}
 		
	public ArrayList<Member> selectMemberList(Connection conn){
		ArrayList<Member> memberList = new ArrayList<>();
		PreparedStatement pstm = null;
		ResultSet rset = null;
		
		try {
			String query  = "select * from tb_member";
			pstm = conn.prepareStatement(query);
			rset = pstm.executeQuery();
			
			while(rset.next()) {
				Member member = new Member();
				member.setUserId(rset.getString("user_id"));
				member.setPassword(rset.getString("password"));
				member.setTell(rset.getString("tell"));
				member.setEmail(rset.getString("email"));
				member.setGrade(rset.getString("grade"));
				member.setRegDate(rset.getDate("reg_date"));
				memberList.add(member);
			}
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.SM01, e);
		} finally {
			jdt.close(rset, pstm);
		}
		return memberList;
	}
	
	public List<Member> selectMemberByRegdate(Connection conn, Date begin, Date end){
		
		List<Member> memberList = new ArrayList<>();
		PreparedStatement pstm = null;
		ResultSet rset = null;
		
		try {
			String query = "select * from tb_member where reg_date between ? and ?";
			
			//3. 쿼리문 실행용 객체를 생성
			pstm = conn.prepareStatement(query);
			
			//4. PreparedStatement 의 쿼리 완성
			pstm.setDate(1, begin);
			pstm.setDate(2, end);
			rset = pstm.executeQuery();
			
			while(rset.next()) {
				Member member = new Member();
				member.setUserId(rset.getString("user_id"));
				member.setGrade(rset.getString("grade"));
				member.setEmail(rset.getString("email"));
				member.setTell(rset.getString("tell"));
				member.setPassword(rset.getString("password"));
				member.setRegDate(rset.getDate("reg_date"));
				memberList.add(member);
			}
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.SM01, e);
		}finally {
			jdt.close(rset, pstm);
		}
		
		return memberList;
	}
	
	public int insertMember(Connection conn, Member member){
		int res = 0;
		PreparedStatement pstm = null;

		try {
			String query = "insert into tb_member(user_id,password,email,tell) "
					+ "values(?,?,?,?)";
			pstm = conn.prepareStatement(query);
			pstm.setString(1, member.getUserId());
			pstm.setString(2, member.getPassword());
			pstm.setString(3, member.getEmail());
			pstm.setString(4, member.getTell());
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.IM01,e);
		}finally {
			jdt.close(pstm);
		}

		return res;
	}
	
	public int updateMember(Connection conn, Member member){
		
		int res = 0;
		PreparedStatement pstm = null;
		
		try {
			String query = "update tb_member set password = ? where user_id = ?";
			pstm = conn.prepareStatement(query);
			pstm.setString(1, member.getPassword());
			pstm.setString(2, member.getUserId());
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.UM01, e);
		}finally {
			jdt.close(pstm);
		}
		
		return res;
	}
	
	public int updateMemberLeave(Connection conn, String userId){
		int res = 0;
		PreparedStatement pstm = null;
		
		try {
			String query = "update tb_member set is_leave = 1 where user_id = ?" ;
			pstm = conn.prepareStatement(query);
			pstm.setString(1, userId);
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataAccessException(ErrorCode.UM01, e);
		}finally {
			jdt.close(pstm);
		}
		return res;
	}
	
	public int deleteMember(Connection conn, String userId) {
		int res = 0;
		PreparedStatement pstm = null;
		
		try {
			String query = "delete from tb_member where user_id = ?'";
			pstm = conn.prepareStatement(query);
			pstm.setString(1, userId);
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataAccessException(ErrorCode.DM01,e);
		}finally {
			jdt.close(pstm);
		}
		return res;
	}
}
