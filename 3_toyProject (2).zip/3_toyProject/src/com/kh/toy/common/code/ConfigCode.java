package com.kh.toy.common.code;

public enum ConfigCode {
	
	DOMAIN("http://localhost:9090"),
	EMAIL("killsky2014@naver.com"),
	UPLOAD_PATH("C:\\CODE\\morning\\05_Servlet\\resources\\upload\\");

	public String desc;
	
	ConfigCode(String desc){
		this.desc = desc;
	}
	
	public String toString() {
		return desc;
	}
}
