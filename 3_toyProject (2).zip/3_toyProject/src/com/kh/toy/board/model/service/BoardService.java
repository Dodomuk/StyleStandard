package com.kh.toy.board.model.service;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kh.toy.board.model.dao.BoardDao;
import com.kh.toy.board.model.vo.Board;
import com.kh.toy.common.exception.DataAccessException;
import com.kh.toy.common.exception.ToAlertException;
import com.kh.toy.common.jdbc.JDBCTemplate;
import com.kh.toy.common.util.file.FileUtil;
import com.kh.toy.common.util.file.FileVO;

public class BoardService {
	JDBCTemplate jdt = JDBCTemplate.getInstance();
	BoardDao boardDao = new BoardDao();

	public void insertBoard(String userId,HttpServletRequest request) {
		Connection conn = jdt.getConnection();
		//게시글 저장
		Map<String,List> boardData = new FileUtil().fileUpload(request);
		
		Board board = new Board();
		board.setUserId(userId);
		board.setTitle(boardData.get("title").get(0).toString());
		board.setContent(boardData.get("content").get(0).toString());
		
		try {
			boardDao.insertBoard(conn, board);
			for(FileVO fileData : (List<FileVO>)boardData.get("fileData")) {
				boardDao.insertFile(conn, fileData);
			}
			jdt.commit(conn);
		}catch(DataAccessException e) {
			jdt.rollback(conn);
			throw new ToAlertException(e.error,e);
		}finally {
			jdt.close(conn);
		}
	}
}
