package com.kh.toy.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.kh.toy.board.model.vo.Board;
import com.kh.toy.common.code.ErrorCode;
import com.kh.toy.common.exception.DataAccessException;
import com.kh.toy.common.jdbc.JDBCTemplate;
import com.kh.toy.common.util.file.FileVO;

public class BoardDao {
	JDBCTemplate jdt = JDBCTemplate.getInstance();
	//게시판 테이블에 게시글 저장
	public int insertBoard(Connection conn, Board board) {
		int res = 0;
		String sql = "insert into tb_board "
				+ "(bd_idx,user_id,title,content) "
				+ "values('b' || sc_board_idx.nextval, ? , ?, ?)";
		
		PreparedStatement pstm = null;
		try {
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, board.getUserId());
			pstm.setString(2, board.getTitle());
			pstm.setString(3, board.getContent());
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.IB01, e);
		}finally {
			jdt.close(pstm);
		}
		
		return res;
	}

	//파일테이블에 파일 정보 저장
	public int insertFile(Connection conn, FileVO fileData) {
		int res = 0;
		String bdIdx = "";
		//1. 새로 등록되는 게시글의 파일 정보 저장
		//	typeIdx값이 시퀀스 currval
		if(fileData.getTypeIdx() == null) {
			bdIdx = "'b'||sc_board_idx.currval";
		//2. 수정할 때 사용자가 파일을 추가 등록해서 파일 정보 저장
		//	수정할 게시글의 bdIdx값
		}else {
			bdIdx = "'" + fileData.getTypeIdx() + "'" ;
		}
		
		String sql = "insert into tb_file "
				+ "(f_idx,type_idx,origin_file_name,rename_file_name,save_path) "
				+ "values(sc_file_idx.nextval,"+bdIdx+",?,?,?)";
		
		PreparedStatement pstm = null;
		try {
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, fileData.getOrginFileName());
			pstm.setString(2, fileData.getRenameFileName());
			pstm.setString(3, fileData.getSavePath());
			res = pstm.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException(ErrorCode.IF01, e);
		}finally {
			jdt.close(pstm);
		}
		
		return res;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
